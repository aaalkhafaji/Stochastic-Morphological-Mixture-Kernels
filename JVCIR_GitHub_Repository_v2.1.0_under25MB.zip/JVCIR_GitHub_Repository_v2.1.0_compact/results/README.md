# Results included on GitHub

This directory retains lightweight CSV/JSON/LaTeX summaries and mathematical checks. Large cached candidate banks, prediction arrays, and compressed per-case metric tables are intentionally excluded so the GitHub repository package remains below 25 MB.

For exact replay using the frozen precomputed artifacts, use the companion Zenodo archival snapshot. For a clean recomputation from the supplied input arrays, run:

```bash
python code/reproduce.py --level full --workdir ../smm-full
```

The excluded-file names, sizes, and SHA-256 digests are listed in `ZENODO_ASSETS.csv`.
